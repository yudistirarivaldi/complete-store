# CHANGELOG

## 2.0.0

Changes:

  - Add package auto discovery.
  - Remove Package Routes.
  - Move Models namspace from \App\Model to \App\Models.
  - Add Global Seeder for Seeding All Data.